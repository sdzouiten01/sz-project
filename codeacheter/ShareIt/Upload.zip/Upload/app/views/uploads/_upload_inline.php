<div class="inlineupload" id="inlineupload-<%= id %>">

  <div class="progress">
  
    <div class="bar">
      <span class="value" style="width: 0%"></span>
    </div>
    
    <span class="label">Uploading... <span class="cancel"></span> </span>
    
  </div>

</div>