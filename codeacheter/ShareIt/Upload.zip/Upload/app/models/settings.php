<?php 

class Settings extends ActiveRecord\Model {
  
  

}

?>