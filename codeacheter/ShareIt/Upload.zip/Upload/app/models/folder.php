<?php 

class Folder extends ActiveRecord\Model {

}

?>